Thank you for your order! <br>
Your order can be found here: <br>
<a href="{{$msg->link}}">{{$msg->link}}</a>