<?php $__env->startSection('content'); ?>
    <div class="alert" style="background-color: black; color: white;">
        <h1>Openingstijden</h1>
    </div>
    <div class="table-responsive">
        <table class="table" style="text-align: center">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Naam van de dag</th>
                <th scope="col">Opening</th>
                <th scope="col">Sluitend</th>
                <th scope="col">Opties</th>
                </tr>
            </thead>
            <tbody
                <?php $__currentLoopData = $weekdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key + 1); ?></th>
                    <td><?php echo e($day->name); ?></td>
                    <td><?php echo e($day->hour_start < 10 ? '0'.$day->hour_start : $day->hour_start); ?>:<?php echo e($day->minutes_start < 10 ? '0'.$day->minutes_start : $day->minutes_start); ?></td>
                    <td><?php echo e($day->hour_end < 10 ? '0'.$day->hour_end : $day->hour_end); ?>:<?php echo e($day->minutes_end < 10 ? '0'.$day->minutes_end : $day->minutes_end); ?></td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#edit<?php echo e($day->id); ?>"><i class="fas fa-edit"></i></button>

                        <!-- Modal -->
                        <div class="modal fade" id="edit<?php echo e($day->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Verandering dag</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="<?php echo e(url('/edit_date/'.$day->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="form-group row">
                                    <tag-random style="padding-top: 8px" class="col-md-6 col-sm-6 col-xs-6 text-right">Starttijd</tag-random><input value="<?php echo e($day->hour_start < 10 ? '0'.$day->hour_start : $day->hour_start); ?>" name="hour_start" style="font-size: 20px;" required placeholder="--" min="00" max="23" type="number" class="form-control col-md-3">
                                </div>
                                <div class="form-group row">
                                    <tag-random style="padding-top: 8px" class="col-md-6 col-sm-6 col-xs-6 text-right">Notulen opening</tag-random> <input value="<?php echo e($day->minutes_start < 10 ? '0'.$day->minutes_start : $day->minutes_start); ?>" name="minutes_start" style="font-size: 20px;" required placeholder="--" min="00" max="59" type="number" class="form-control col-md-3">
                                </div>
                                <div class="form-group row">
                                    <!-- <label>Sluitingstijd</label> -->
                                    <tag-random style="padding-top: 8px" class="col-md-6 col-sm-6 col-xs-6 text-right">Sluitingstijd</tag-random> <input value="<?php echo e($day->hour_end < 10 ? '0'.$day->hour_end : $day->hour_end); ?>" name="hour_end" style="font-size: 20px;" required placeholder="--" min="00" max="23" type="number" class="form-control col-md-3">
                                </div>
                                <div class="form-group row">
                                    <tag-random style="padding-top: 8px" class="col-md-6 col-sm-6 col-xs-6 text-right">Notulen sluiten</tag-random> <input value="<?php echo e($day->minutes_end < 10 ? '0'.$day->minutes_end : $day->minutes_end); ?>" name="minutes_end" style="font-size: 20px;" required placeholder="--"  min="00" max="59" type="number" class="form-control col-md-3">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Sluiten</button>
                                <button type="submit" class="btn btn-primary">Verander</button>
                            </div>
                            </form>
                            </div>
                        </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/admin/schedule.blade.php ENDPATH**/ ?>