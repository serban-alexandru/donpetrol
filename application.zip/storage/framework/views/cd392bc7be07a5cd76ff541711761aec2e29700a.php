<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="alert" style="background-color: black; color: white;">
            <h1>Categories</h1>
        </div>
        <div class="table-responsive">
            <table class="table" style="text-align: center">
                <thead> 
                    <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Products</th>
                    <th scope="col">Categories</th>
                    <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($category->id); ?></th>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->products->count()); ?></td>
                        <td><?php echo e($category->subcategories->count()); ?></td>
                        <td style="max-width: 300px; width: 300px">
                            <button class="btn btn-warning" data-toggle="modal" data-target="#editCat<?php echo e($category->id); ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <!-- Modal -->
                            <div class="modal fade" id="editCat<?php echo e($category->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="<?php echo e(url('/edit_category/'.$category->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label>Name:</label>
                                        <input value="<?php echo e($category->name); ?>" type="text" required placeholder="name" name="name" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Icon:</label>
                                        <input value="<?php echo e($category->icon); ?>" type="text" required placeholder="icon" name="icon" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Description:</label>
                                        <textarea name="description" cols="30" rows="10" placeholder="description" class="form-control"><?php echo e($category->description); ?></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" style="background: black">Save changes</button>
                                </div>
                                </form>
                                </div>
                            </div>
                            </div>
                            <a href="<?php echo e(url('/category/'.$category->id)); ?>">
                                <button class="btn btn-success" style="padding-top: 9px; padding-bottom: 9px">
                                    <i class="fas fa-eye" style="font-size: 20px"></i>
                                </button>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($categories->links()); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/admin/categories.blade.php ENDPATH**/ ?>