<?php $__env->startSection('content'); ?>

<style>
    .btn-primary:hover{
        background-color: black !important;
    }
</style>

<div class="container-fluid">
    <div class="alert" style="background-color: black; color: white;">
        <h1>Bestelling #<?php echo e($order->id); ?> betaald</h1>
        <p>Wij hebben uw bestelling goed ontvangen!</p>
    </div>

    <div class="card">
        <div class="card-header"></div>
        <div class="card-body">
            <div class="row">
            <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $product = $product->product
                ?>
                <div class="col-md-4 col-sm-6 col-xs-12 text-center">
                    <div class="card" style="background: black;">
                        <div class="card-header" style="font-size: 30px;color: white; padding: 20px">
                            <i class="<?php echo e($product->category->icon); ?>" style="font-size: 60px;"></i><br><br>
                            <?php echo e($product->name); ?>

                            <p style="font-size: 19px; margin-top: 7px"><?php echo e($product->description); ?></p>
                            <div style="margin: 5px 0px"><?php echo e($product->price); ?>€</div>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
            <a href="<?php echo e(url('/menu')); ?>">
                <button class="btn btn-primary">Menu</button>
            </a>
        </div>
    </div>

</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/paymentSuccess.blade.php ENDPATH**/ ?>