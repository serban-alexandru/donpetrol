Thank you for your order! <br>
Your order can be found here: <br>
<a href="<?php echo e($msg->link); ?>"><?php echo e($msg->link); ?></a><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/email/message.blade.php ENDPATH**/ ?>