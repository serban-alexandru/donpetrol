<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="alert" style="background-color: black; color: white;">
            <h1>
            <?php if($category->category): ?>
            <?php echo e($category->category->name); ?> - 
            <?php endif; ?>
            <i class="<?php echo e($category->icon); ?>"></i> <?php echo e($category->name); ?></h1>
            <h4><?php echo e($category->description); ?></h4>
        </div>
        <div class="table-responsive">
            <table class="table" style="text-align: center">
                <thead> 
                    <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($product->id); ?></th>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->price); ?>€</td>
                        <td style="max-width: 300px; width: 300px">
                        <button class="btn btn-warning" data-toggle="modal" data-target="#editModal<?php echo e($product->id); ?>"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-danger" data-toggle="modal" data-target="#deleteModal<?php echo e($product->id); ?>"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>

                    <!-- Modal -->
                    <div class="modal fade" id="editModal<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Bewerk</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(url('/edit_product/'.$product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Name:</label>
                                <input type="text" name="name" value="<?php echo e($product->name); ?>" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Description:</label>
                                <textarea name="description" cols="30" rows="5" class="form-control"><?php echo e($product->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Price:</label>
                                <input type="number" step="0.1" value="<?php echo e($product->price); ?>" name="price" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Table part:</label>
                                <input type="text" name="table_part" value="<?php echo e($product->table_part); ?>" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Table number:</label>
                                <input type="text" name="table_number" value="<?php echo e($product->table_number); ?>" required class="form-control">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Sluiten</button>
                            <button type="submit" class="btn btn-warning">Wijzigingen opslaan</button>
                        </div>
                        </form>
                    </div>
                    </div>
                    </div>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="deleteModal<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Verwijder</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            Bent u zeker dat u dit product wilt verwijderen?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Sluiten</button>
                            <a href="<?php echo e(url('/delete_product/'.$product->id)); ?>">
                                <button type="button" class="btn btn-danger">Verwijderen</button>
                            </a>
                        </div>
                        </div>
                    </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($products->links()); ?>

        </div>

        <button class="btn btn-success" data-toggle="modal" data-target="#addModal">Product toevoegen</button>

        <!-- Modal -->
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Product toevoegen</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('/add_product')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="form-group">
                    <label>Naam:</label>
                    <input type="text" name="name" required class="form-control">
                </div>
                <div class="form-group">
                    <label>Beschrijving:</label>
                    <textarea name="description" cols="30" rows="5" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label>Prijs:</label>
                    <input type="number" step="0.1" name="price" required class="form-control">
                </div>
                <div class="form-group">
                    <label>Table part:</label>
                    <input type="text" name="table_part" required class="form-control">
                </div>
                <div class="form-group">
                    <label>Table number:</label>
                    <input type="text" name="table_number" required class="form-control">
                </div>
                <input type="text" hidden name="category_id" value="<?php echo e($category->id); ?>" class="form-control">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Sluiten</button>
                <button type="submit" class="btn btn-success">Product toevoegen</button>
            </div>
            </form>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/admin/productsInCategory.blade.php ENDPATH**/ ?>