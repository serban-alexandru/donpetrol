<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-4 col-sm-6 col-xs-12 text-center">
        <div class="card" style="background: black">
            <div class="card-header" style="font-size: 30px;color: white; padding: 20px">
                <i class="fas fa-list" style="font-size: 60px;"></i><br><br>
                Categories: <?php echo e($categories->count()); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12 text-center">
        <div class="card" style="background: black">
            <div class="card-header" style="font-size: 30px;color: white; padding: 20px">
                <i class="fab fa-product-hunt" style="font-size: 60px;"></i><br><br>
                Products: <?php echo e($products->count()); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12 text-center">
        <div class="card" style="background: black">
            <div class="card-header" style="font-size: 30px;color: white; padding: 20px">
                <i class="fas fa-shopping-cart" style="font-size: 60px;"></i><br><br>
                Orders: <?php echo e($orders->count()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/admin/home.blade.php ENDPATH**/ ?>