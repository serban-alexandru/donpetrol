<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="alert" style="background-color: black; color: white;">
        <h1>Bestellingen</h1>
    </div>

    <div class="table-responsive">

    <table class="table" style="text-align: center">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Type</th>
            <th scope="col">Afhaaltijd</th>
            <th scope="col">Waarde</th>
            <th scope="col">Alle orders</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $sum = 0;
            ?>
            <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $sum += $product->quantity * $product->product->price
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($key+1); ?></th>
                <td>
                <!-- <?php if($order->type == 'eat_in'): ?>
                Eat in
                <?php else: ?>
                Take out
                <?php endif; ?> -->
                Take away
                </td>
                <td>
                <?php if($order->delivery_time == '0'): ?>
                    As soon as possible
                <?php else: ?>
                    <?php echo e($order->delivery_time); ?>

                <?php endif; ?>
                </td>
                <td>€ <?php echo e($sum); ?> </td>
                <td>
                    <button data-toggle="modal" data-target="#view<?php echo e($order->id); ?>" class="btn" style="padding-top: 9px; padding-bottom: 9px">
                        <i class="fas fa-list-alt" style="font-size: 20px"></i>
                    </button>
                </td>
            </tr>

            <!-- Modal -->
            <div class="modal fade" id="view<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Order #<?php echo e($order->id); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h4>Name: <?php echo e($order->user->name); ?></h4>
                    <h4>Type: Order 
                    <!-- <?php if($order->type == 'eat_in'): ?>
                    Eat in
                    <?php else: ?>
                    Take out
                    <?php endif; ?> -->
                    </h4>
                    <h4>Delivery time: 
                        <?php if($order->delivery_time == '0'): ?>
                            As soon as possible
                        <?php else: ?>
                            <?php echo e($order->delivery_time); ?>

                        <?php endif; ?>
                    </h4>
                    <!-- <h4>Street and house number: <?php echo e($order->street_and_house); ?></h4> -->
                    <h4>Phone number: <?php echo e($order->phone); ?></h4>
                    <!-- <h4>Postcode: <?php echo e($order->postcode); ?></h4> -->
                    <h4>Comments: "<?php echo e($order->comments); ?>"</h4>
                    <h4>Ordered products:</h4>
                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="margin: 10px 0px">
                        <div class="card-header" style="font-size: 20px; border: 1px solid black">
                            <?php echo e($product->product->name); ?> <tag-random class="text-warning">X</tag-random> <?php echo e($product->quantity); ?>

                            <tag-random class="float-right">€ <?php echo e($product->quantity * $product->product->price); ?> </tag-random>
                        </div>
                    </div>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <a href="<?php echo e(url('/delete_order/'.$order->id)); ?>">
                        <button type="button" style="background:black" class="btn btn-primary">Delete order</button>
                    </a>
                </div>
                </div>
            </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/admin/allOrders.blade.php ENDPATH**/ ?>