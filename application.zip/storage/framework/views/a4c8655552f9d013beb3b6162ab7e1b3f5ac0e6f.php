<?php $__env->startSection('content'); ?>

<?php if(!Session::has('order_type')): ?>
    <script>
        var url= "<?php echo e(url('/')); ?>"; 
        window.location = url; 
    </script>
<?php endif; ?>

<style>
    .col-md-6{
        margin-bottom: 20px !important;
    }
</style>
<div class="container">
<div class="text-center">
<h2><?php echo e(Route::currentRouteName()); ?></h2>
<br>
<p class="lead"></p>
</div>

<div class="row">
<div class="col-md-4 order-md-2 mb-4">
    <h4 class="d-flex justify-content-between align-items-center mb-3">
    <span class="text-muted">Your cart</span>
    <?php
        $count = 0;
    ?>
    <?php $__currentLoopData = Auth::user()->cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $count+=$item->quantity;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <span class="badge badge-secondary badge-pill"><?php echo e($count); ?></span>
    </h4>
    <ul class="list-group mb-3">
    <?php    
        $sum = 0;
    ?>
    <?php $__currentLoopData = Auth::user()->cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item d-flex justify-content-between lh-condensed">
        <div>
        <h6 class="my-0"><?php echo e($item->product->name); ?> <tag-random class="text-warning">x</tag-random> <?php echo e($item->quantity); ?></h6>
        <small class="text-muted">(<?php echo e($item->product->category->name); ?>)</small>
        </div>
        <span class="text-muted">$<?php echo e($item->quantity * $item->product->price); ?></span>
    </li>
    <?php
        $sum += $item->quantity * $item->product->price;
    ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item d-flex justify-content-between">
        <span>Total (USD)</span>
        <strong>$<?php echo e($sum); ?></strong>
    </li>
    </ul>
</div>
<div class="col-md-8 order-md-1">
    <form action="<?php echo e(url('send_order')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <h3 class="mb-3">Waar wil je dat je bestelling bezorgd wordt?</h3>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">Straatnaam en huisnummer</label>
                <br>
                <input type="text" required name="street_and_house" placeholder="Adress" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">Postcode</label>
                <br>
                <input type="string" required name="postcode" placeholder="Adress" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">Plaatsnaam</label>
                <br>
                <input type="text" required name="place_name" placeholder="Plaatsnaam" class="form-control">
            </div>
        </div>
    </div>
    <div class="form-group">
        <h3 class="mb-3">Hoe ben je te bereiken?</h3>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">Naam</label>
                <br>
                <input type="text" required name="name" placeholder="Naam" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">E-mailadres</label>
                <br>
                <input type="text" required name="email" placeholder="E-mailadres" class="form-control">
            </div>
        </div>
        <br>
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">Telefoonnummer</label>
                <br>
                <input type="text" required name="phone" placeholder="Telefoonnummer" class="form-control">
            </div>
        </div>
        <br>
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">Bedrijfsnaam</label>
                <br>
                <input type="text" required name="company_name" placeholder="Bedrijfsnaam" class="form-control">
            </div>
        </div>
        <br>
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">Gewenste bezorgtijd</label>
                <br>
                <select name="delivery_time" class="form-control" required>
                    <option value="0">Zo snel mogelijk</option>
                    <option value="1" required style="color: black" id="nextDate"></option>
                    <option value="2" required style="color: black" id="afterDate"></option>
                    <option value="3" required style="color: black" id="after2Date"></option>
                    <option value="3" required style="color: black" id="after3Date"></option>
                </select>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label style="font-size: 20px">Opmerkingen voor het restaurant?</label>
                <br>
                <textarea required rows="10" name="comments" placeholder="Opmerkingen" class="form-control"></textarea>
            </div>
        </div>
    </div>
    <hr class="mb-4">
    <button class="btn btn-primary btn-lg btn-block" type="submit">Continue to checkout</button>
    </form>
</div>
</div>

<script>
var now = new Date();
// var hour = now.getHours();
// var minutes = now.getMinutes();
// var ampm = "AM";
// if (minutes < 30) {
//     minutes = "30";
// } else {
//     minutes = "00";
//     ++hour;
// }
// if (hour > 23) {
//     hour = 12;
// } else if (hour > 12) {
//     hour = hour - 12;
//     ampm = "PM";
// } else if (hour == 12) {
//     ampm = "PM";
// } else if (hour == 0) {
//     hour = 12;
// }

if(now.getMinutes() <= 30){

    d1 = new Date();
    d2 = new Date();
    d2.setMinutes(d1.getMinutes() + 30-d1.getMinutes());
    d2.setSeconds(0);
    nextDate = d2;
    console.log(nextDate);
    if(d2.getMinutes() < 10){
    stri = '0';
    }else{
    stri = '';
    }
    document.getElementById('nextDate').innerHTML = nextDate.getHours()+':'+nextDate.getMinutes()+stri;
    document.getElementById('nextDate').setAttribute('value', nextDate.getHours()+':'+nextDate.getMinutes()+stri);

    d2.setMinutes(d2.getMinutes() + 30);
    afterDate = d2;
    console.log(afterDate);
    if(d2.getMinutes() < 10){
    stri = '0';
    }else{
    stri = '';
    }
    document.getElementById('afterDate').innerHTML = afterDate.getHours()+':'+afterDate.getMinutes()+stri;
    document.getElementById('afterDate').setAttribute('value', nextDate.getHours()+':'+nextDate.getMinutes()+stri);

    d2.setMinutes(d2.getMinutes() + 30);
    after2Date = d2;
    console.log(after2Date);
    if(d2.getMinutes() < 10){
    stri = '0';
    }else{
    stri = '';
    }
    document.getElementById('after2Date').innerHTML = after2Date.getHours()+':'+after2Date.getMinutes()+stri;
    document.getElementById('after2Date').setAttribute('value', nextDate.getHours()+':'+nextDate.getMinutes()+stri);

    d2.setMinutes(d2.getMinutes() + 30);
    after3Date = d2;
    // console.log(after2Date);
    if(d2.getMinutes() < 10){
    stri = '0';
    }else{
    stri = '';
    }
    document.getElementById('after3Date').innerHTML = after3Date.getHours()+':'+after3Date.getMinutes()+stri;
    document.getElementById('after3Date').setAttribute('value', nextDate.getHours()+':'+nextDate.getMinutes()+stri);

}else{
    d1 = new Date();
    d2 = new Date();
    d2.setHours(d1.getHours() + 1);
    d2.setMinutes(0);
    nextDate = d2;
    console.log(nextDate);
    if(d2.getMinutes() < 10){
    stri = '0';
    }else{
    stri = '';
    }
    document.getElementById('nextDate').innerHTML = nextDate.getHours()+':'+nextDate.getMinutes()+stri;
    document.getElementById('nextDate').setAttribute('value', nextDate.getHours()+':'+nextDate.getMinutes()+stri);

    d2.setMinutes(d2.getMinutes() + 30);
    afterDate = d2;
    console.log(afterDate);
    if(d2.getMinutes() < 10){
    stri = '0';
    }else{
    stri = '';
    }
    document.getElementById('afterDate').innerHTML = afterDate.getHours()+':'+afterDate.getMinutes()+stri;
    document.getElementById('afterDate').setAttribute('value', nextDate.getHours()+':'+nextDate.getMinutes()+stri);

    d2.setMinutes(d2.getMinutes() + 30);
    after2Date = d2;
    console.log(after2Date);
    if(d2.getMinutes() < 10){
    stri = '0';
    }else{
    stri = '';
    }
    document.getElementById('after2Date').innerHTML = after2Date.getHours()+':'+after2Date.getMinutes()+stri;
    document.getElementById('after2Date').setAttribute('value', nextDate.getHours()+':'+nextDate.getMinutes()+stri);

    d2.setMinutes(d2.getMinutes() + 30);
    after3Date = d2;
    // console.log(after2Date);
    if(d2.getMinutes() < 10){
    stri = '0';
    }else{
    stri = '';
    }
    document.getElementById('after3Date').innerHTML = after3Date.getHours()+':'+after3Date.getMinutes()+stri;
    document.getElementById('after3Date').setAttribute('value', nextDate.getHours()+':'+nextDate.getMinutes()+stri);

}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/checkout.blade.php ENDPATH**/ ?>