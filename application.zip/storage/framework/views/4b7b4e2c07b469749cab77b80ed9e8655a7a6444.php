<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="alert" style="background-color: black; color: white;">
            <h1>Menu</h1>
        </div>

        <div id="accordion">
            <div class="buttons">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!$category->category_id): ?>
                <button class="btn btn-warning" data-toggle="collapse" data-target="#collapse<?php echo e($category->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($category->id); ?>">
                <?php echo e($category->name); ?>

                </button>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <style>
                    form #input-wrap {
                    margin: 0px;
                    padding: 0px;
                    }

                    input#number<?php echo e($product->id); ?> {
                    text-align: center;
                    border: none;
                    border-top: 1px solid #ddd;
                    border-bottom: 1px solid #ddd;
                    margin: 0px;
                    width: 40px;
                    height: 40px;
                    }

                    input[type=number]::-webkit-inner-spin-button,
                    input[type=number]::-webkit-outer-spin-button {
                        -webkit-appearance: none;
                        margin: 0;
                    }
                    </style>
                    <script>
                    function increaseValue<?php echo e($product->id); ?>() {
                    var value = parseInt(document.getElementById('number<?php echo e($product->id); ?>').value, 10);
                    value = isNaN(value) ? 0 : value;
                    value++;
                    document.getElementById('number<?php echo e($product->id); ?>').value = value;
                    }

                    function decreaseValue<?php echo e($product->id); ?>() {
                    var value = parseInt(document.getElementById('number<?php echo e($product->id); ?>').value, 10);
                    value = isNaN(value) ? 0 : value;
                    value < 1 ? value = 1 : '';
                    value--;
                    document.getElementById('number<?php echo e($product->id); ?>').value = value;
                    }
                    </script>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div style="margin-top: 20px">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="margin: 0px">
                    <div id="collapse<?php echo e($category->id); ?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <h2><?php echo e($category->name); ?></h2>
                        <h4><?php echo e($category->description); ?></h4>
                        <div class="row">
                        <div class="col-md-12">
                        <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($subcat->products->count() > 0): ?>
                            <h2 style="margin-bottom: -20px"><?php echo e($subcat->name); ?></h2>
                            <?php endif; ?>
                            <div class="row">
                            <?php $__currentLoopData = $subcat->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 col-sm-6 col-xs-12 text-center">
                                    <div class="card" style="background: black;">
                                        <div class="card-header" style="font-size: 30px;color: white; padding: 20px">
                                            <i class="<?php echo e($product->category->icon); ?>" style="font-size: 60px;"></i><br><br>
                                            <?php echo e($product->name); ?>

                                            <p style="font-size: 19px; margin-top: 7px"><?php echo e($product->description); ?></p>
                                            <form style="margin-top: 10px" action="<?php echo e(url('/add_to_cart/'.$product->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button style="margin-top: 1px" type="button" class="btn btn-warning" id="decrease" onclick="decreaseValue<?php echo e($product->id); ?>()">-</button>
                                                <input type="number" name="quantity" id="number<?php echo e($product->id); ?>" value="1" min="1" />
                                                <button style="margin-top: 1px" type="button" class="btn btn-warning" id="increase" onclick="increaseValue<?php echo e($product->id); ?>()">+</button>
                                                <div style="margin: 5px 0px"><?php echo e($product->price); ?>€</div>
                                                <button class="btn btn-warning">Voeg toe</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        

                        <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 col-sm-6 col-xs-12 text-center">
                                <div class="card" style="background: black;">
                                    <div class="card-header" style="font-size: 30px;color: white; padding: 20px">
                                        <i class="<?php echo e($product->category->icon); ?>" style="font-size: 60px;"></i><br><br>
                                        <?php echo e($product->name); ?>

                                        <p style="font-size: 19px; margin-top: 7px"><?php echo e($product->description); ?></p>
                                        <form style="margin-top: 10px" action="<?php echo e(url('/add_to_cart/'.$product->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button style="margin-top: 1px" type="button" class="btn btn-warning" id="decrease" onclick="decreaseValue<?php echo e($product->id); ?>()">-</button>
                                            <input type="number" name="quantity" id="number<?php echo e($product->id); ?>" value="1" min="1" />
                                            <button style="margin-top: 1px" type="button" class="btn btn-warning" id="increase" onclick="increaseValue<?php echo e($product->id); ?>()">+</button>
                                            <div style="margin: 5px 0px"><?php echo e($product->price); ?>€</div>
                                            <button class="btn btn-warning">Voeg toe</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div> 

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donpetrol\resources\views/admin/orders.blade.php ENDPATH**/ ?>